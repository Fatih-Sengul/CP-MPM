/**
 * Contains all the visitors for publishing the candies.
 * 
 * @author Renaud Pawlak
 */
package org.jsweet.publisher.visitor;