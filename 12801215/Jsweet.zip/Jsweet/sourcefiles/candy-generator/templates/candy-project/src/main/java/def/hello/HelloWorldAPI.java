package def.hello;

/**
 * An example of a library definition.
 */
public class HelloWorldAPI {
	native public static def.js.String hello(CharSequence message);	
}
