package def.dom;
public class MimeType extends def.js.Object {
    public String description;
    public Plugin enabledPlugin;
    public String suffixes;
    public String type;
    public static MimeType prototype;
    public MimeType(){}
}

