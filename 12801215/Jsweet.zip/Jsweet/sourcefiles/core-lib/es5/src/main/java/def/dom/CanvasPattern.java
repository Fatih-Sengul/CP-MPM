package def.dom;
public class CanvasPattern extends def.js.Object {
    public static CanvasPattern prototype;
    public CanvasPattern(){}
}

