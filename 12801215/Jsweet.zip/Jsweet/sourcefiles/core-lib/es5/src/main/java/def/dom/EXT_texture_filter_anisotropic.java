package def.dom;
public class EXT_texture_filter_anisotropic extends def.js.Object {
    public double MAX_TEXTURE_MAX_ANISOTROPY_EXT;
    public double TEXTURE_MAX_ANISOTROPY_EXT;
    public static EXT_texture_filter_anisotropic prototype;
    public EXT_texture_filter_anisotropic(){}
}

