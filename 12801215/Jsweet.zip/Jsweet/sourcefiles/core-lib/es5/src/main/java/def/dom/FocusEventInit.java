package def.dom;
@jsweet.lang.Interface
public abstract class FocusEventInit extends UIEventInit {
    @jsweet.lang.Optional
    public EventTarget relatedTarget;
}

