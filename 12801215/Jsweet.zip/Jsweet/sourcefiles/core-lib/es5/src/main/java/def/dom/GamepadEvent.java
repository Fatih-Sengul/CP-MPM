package def.dom;
public class GamepadEvent extends Event {
    public Gamepad gamepad;
    public static GamepadEvent prototype;
    public GamepadEvent(){}
}

