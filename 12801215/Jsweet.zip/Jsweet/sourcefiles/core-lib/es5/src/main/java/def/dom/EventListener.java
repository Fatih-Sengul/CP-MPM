package def.dom;
public interface EventListener {
    public void $apply(Event evt);
}

