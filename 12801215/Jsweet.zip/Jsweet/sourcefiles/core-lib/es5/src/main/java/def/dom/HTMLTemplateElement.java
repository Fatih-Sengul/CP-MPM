package def.dom;
public class HTMLTemplateElement extends HTMLElement {
    public DocumentFragment content;
    public static HTMLTemplateElement prototype;
    public HTMLTemplateElement(){}
}

