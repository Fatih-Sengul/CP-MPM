package def.dom;
public class HTMLSpanElement extends HTMLElement {
    public static HTMLSpanElement prototype;
    public HTMLSpanElement(){}
}

