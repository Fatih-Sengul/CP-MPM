package def.dom;
public class Coordinates extends def.js.Object {
    public double accuracy;
    public double altitude;
    public double altitudeAccuracy;
    public double heading;
    public double latitude;
    public double longitude;
    public double speed;
    public static Coordinates prototype;
    public Coordinates(){}
}

