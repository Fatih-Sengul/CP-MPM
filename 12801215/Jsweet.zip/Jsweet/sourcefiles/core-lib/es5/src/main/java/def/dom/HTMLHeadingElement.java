package def.dom;
public class HTMLHeadingElement extends HTMLElement {
    /**
      * Sets or retrieves a value that indicates the table alignment.
      */
    public String align;
    public String clear;
    public static HTMLHeadingElement prototype;
    public HTMLHeadingElement(){}
}

