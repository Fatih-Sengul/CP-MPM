package def.dom;
public interface FrameRequestCallback {
    public void $apply(double time);
}

