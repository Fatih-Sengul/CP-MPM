package def.dom;
public interface DecodeErrorCallback {
    public void $apply(DOMException error);
}

