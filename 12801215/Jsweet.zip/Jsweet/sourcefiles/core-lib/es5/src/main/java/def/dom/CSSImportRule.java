package def.dom;
public class CSSImportRule extends CSSRule {
    public String href;
    public MediaList media;
    public CSSStyleSheet styleSheet;
    public static CSSImportRule prototype;
    public CSSImportRule(){}
}

