package def.dom;
public class HTMLTitleElement extends HTMLElement {
    /**
      * Retrieves or sets the text of the object as a string. 
      */
    public String text;
    public static HTMLTitleElement prototype;
    public HTMLTitleElement(){}
}

