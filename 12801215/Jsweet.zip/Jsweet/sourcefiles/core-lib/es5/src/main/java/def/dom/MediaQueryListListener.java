package def.dom;
public interface MediaQueryListListener {
    public void $apply(MediaQueryList mql);
}

