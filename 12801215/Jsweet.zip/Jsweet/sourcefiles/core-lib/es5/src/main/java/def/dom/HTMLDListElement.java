package def.dom;
public class HTMLDListElement extends HTMLElement {
    public Boolean compact;
    public static HTMLDListElement prototype;
    public HTMLDListElement(){}
}

