package def.dom;
@jsweet.lang.Interface
public abstract class KeyAlgorithm extends def.js.Object {
    @jsweet.lang.Optional
    public String name;
}

