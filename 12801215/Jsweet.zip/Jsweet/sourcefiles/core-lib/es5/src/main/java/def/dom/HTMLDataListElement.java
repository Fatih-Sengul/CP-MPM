package def.dom;
public class HTMLDataListElement extends HTMLElement {
    public HTMLCollection options;
    public static HTMLDataListElement prototype;
    public HTMLDataListElement(){}
}

