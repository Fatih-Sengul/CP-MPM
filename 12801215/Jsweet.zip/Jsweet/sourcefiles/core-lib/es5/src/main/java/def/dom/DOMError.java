package def.dom;
public class DOMError extends def.js.Object {
    public String name;
    native public String toString();
    public static DOMError prototype;
    public DOMError(){}
}

