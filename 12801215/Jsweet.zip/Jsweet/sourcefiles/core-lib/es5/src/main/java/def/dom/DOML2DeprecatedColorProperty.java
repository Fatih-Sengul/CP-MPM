package def.dom;
@jsweet.lang.Interface
public abstract class DOML2DeprecatedColorProperty extends def.js.Object {
    public String color;
}

