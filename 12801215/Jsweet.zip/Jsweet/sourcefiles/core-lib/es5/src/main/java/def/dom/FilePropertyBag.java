package def.dom;
@jsweet.lang.Interface
public abstract class FilePropertyBag extends def.js.Object {
    @jsweet.lang.Optional
    public String type;
    @jsweet.lang.Optional
    public double lastModified;
}

