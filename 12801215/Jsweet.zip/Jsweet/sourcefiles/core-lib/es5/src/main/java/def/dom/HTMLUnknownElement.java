package def.dom;
public class HTMLUnknownElement extends HTMLElement {
    public static HTMLUnknownElement prototype;
    public HTMLUnknownElement(){}
}

