package def.dom;
public class HTMLNextIdElement extends HTMLElement {
    public String n;
    public static HTMLNextIdElement prototype;
    public HTMLNextIdElement(){}
}

