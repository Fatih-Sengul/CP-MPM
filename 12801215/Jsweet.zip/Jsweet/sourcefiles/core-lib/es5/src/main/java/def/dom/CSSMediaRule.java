package def.dom;
public class CSSMediaRule extends CSSConditionRule {
    public MediaList media;
    public static CSSMediaRule prototype;
    public CSSMediaRule(){}
}

