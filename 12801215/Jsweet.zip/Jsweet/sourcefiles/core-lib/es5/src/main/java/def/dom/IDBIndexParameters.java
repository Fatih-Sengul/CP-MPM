package def.dom;
@jsweet.lang.Interface
public abstract class IDBIndexParameters extends def.js.Object {
    @jsweet.lang.Optional
    public Boolean unique;
    @jsweet.lang.Optional
    public Boolean multiEntry;
}

