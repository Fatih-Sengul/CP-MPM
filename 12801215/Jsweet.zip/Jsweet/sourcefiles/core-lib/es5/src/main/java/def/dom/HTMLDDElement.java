package def.dom;
public class HTMLDDElement extends HTMLElement {
    /**
      * Sets or retrieves whether the browser automatically performs wordwrap.
      */
    public Boolean noWrap;
    public static HTMLDDElement prototype;
    public HTMLDDElement(){}
}

