package def.dom;
public class MSPluginsCollection extends def.js.Object {
    public double length;
    native public void refresh(Boolean reload);
    public static MSPluginsCollection prototype;
    public MSPluginsCollection(){}
    native public void refresh();
}

