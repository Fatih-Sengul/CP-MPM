package def.dom;
@jsweet.lang.Interface
public abstract class LinkStyle extends def.js.Object {
    public StyleSheet sheet;
}

