package def.dom;
@jsweet.lang.Interface
public abstract class ChildNode extends def.js.Object {
    native public void remove();
}

