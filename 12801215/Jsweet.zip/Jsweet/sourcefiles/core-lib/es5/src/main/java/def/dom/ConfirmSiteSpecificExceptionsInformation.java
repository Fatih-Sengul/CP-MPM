package def.dom;
@jsweet.lang.Interface
public abstract class ConfirmSiteSpecificExceptionsInformation extends ExceptionInformation {
    @jsweet.lang.Optional
    public String[] arrayOfDomainStrings;
}

