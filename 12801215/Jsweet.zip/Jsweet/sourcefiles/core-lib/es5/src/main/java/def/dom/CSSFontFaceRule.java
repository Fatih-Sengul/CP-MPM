package def.dom;
public class CSSFontFaceRule extends CSSRule {
    public CSSStyleDeclaration style;
    public static CSSFontFaceRule prototype;
    public CSSFontFaceRule(){}
}

