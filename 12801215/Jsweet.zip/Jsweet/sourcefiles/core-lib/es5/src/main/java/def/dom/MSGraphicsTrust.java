package def.dom;
public class MSGraphicsTrust extends def.js.Object {
    public Boolean constrictionActive;
    public String status;
    public static MSGraphicsTrust prototype;
    public MSGraphicsTrust(){}
}

