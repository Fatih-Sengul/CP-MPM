package def.dom;
import def.js.ArrayBuffer;
public class DataCue extends TextTrackCue {
    public ArrayBuffer data;
    public static DataCue prototype;
    public DataCue(){}
}

