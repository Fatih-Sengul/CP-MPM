package def.dom;
@jsweet.lang.Interface
public abstract class IDBEnvironment extends def.js.Object {
    public IDBFactory indexedDB;
    public IDBFactory msIndexedDB;
}

