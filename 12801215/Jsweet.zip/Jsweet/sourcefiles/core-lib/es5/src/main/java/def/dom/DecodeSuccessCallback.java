package def.dom;
public interface DecodeSuccessCallback {
    public void $apply(AudioBuffer decodedData);
}

