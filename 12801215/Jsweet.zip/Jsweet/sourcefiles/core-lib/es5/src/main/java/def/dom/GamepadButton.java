package def.dom;
public class GamepadButton extends def.js.Object {
    public Boolean pressed;
    public double value;
    public static GamepadButton prototype;
    public GamepadButton(){}
}

