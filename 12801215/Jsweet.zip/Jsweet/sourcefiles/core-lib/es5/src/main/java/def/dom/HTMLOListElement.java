package def.dom;
public class HTMLOListElement extends HTMLElement {
    public Boolean compact;
    /**
      * The starting number.
      */
    public double start;
    public String type;
    public static HTMLOListElement prototype;
    public HTMLOListElement(){}
}

