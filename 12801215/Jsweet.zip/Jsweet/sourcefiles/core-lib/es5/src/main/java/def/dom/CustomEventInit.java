package def.dom;
@jsweet.lang.Interface
public abstract class CustomEventInit extends EventInit {
    @jsweet.lang.Optional
    public Object detail;
}

