package def.dom;
public class HTMLDocument extends Document {
    public static HTMLDocument prototype;
    public HTMLDocument(){}
}

