package def.dom;
@jsweet.lang.Interface
public abstract class CompositionEventInit extends UIEventInit {
    @jsweet.lang.Optional
    public String data;
}

