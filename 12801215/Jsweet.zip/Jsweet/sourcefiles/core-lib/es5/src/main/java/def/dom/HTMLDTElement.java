package def.dom;
public class HTMLDTElement extends HTMLElement {
    /**
      * Sets or retrieves whether the browser automatically performs wordwrap.
      */
    public Boolean noWrap;
    public static HTMLDTElement prototype;
    public HTMLDTElement(){}
}

