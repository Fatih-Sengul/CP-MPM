package def.dom;
public class MediaElementAudioSourceNode extends AudioNode {
    public static MediaElementAudioSourceNode prototype;
    public MediaElementAudioSourceNode(){}
}

