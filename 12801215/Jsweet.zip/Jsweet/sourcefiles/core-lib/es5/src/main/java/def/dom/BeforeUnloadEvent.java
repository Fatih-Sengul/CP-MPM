package def.dom;
public class BeforeUnloadEvent extends Event {
    public Object returnValue;
    public static BeforeUnloadEvent prototype;
    public BeforeUnloadEvent(){}
}

