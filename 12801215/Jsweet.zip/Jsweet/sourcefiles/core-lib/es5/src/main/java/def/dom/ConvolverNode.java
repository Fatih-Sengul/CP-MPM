package def.dom;
public class ConvolverNode extends AudioNode {
    public AudioBuffer buffer;
    public Boolean normalize;
    public static ConvolverNode prototype;
    public ConvolverNode(){}
}

