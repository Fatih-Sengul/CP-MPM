package def.dom;
@jsweet.lang.Interface
public abstract class Algorithm extends def.js.Object {
    @jsweet.lang.Optional
    public String name;
}

