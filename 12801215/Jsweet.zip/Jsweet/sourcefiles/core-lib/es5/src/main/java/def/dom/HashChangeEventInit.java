package def.dom;
@jsweet.lang.Interface
public abstract class HashChangeEventInit extends EventInit {
    @jsweet.lang.Optional
    public String newURL;
    @jsweet.lang.Optional
    public String oldURL;
}

