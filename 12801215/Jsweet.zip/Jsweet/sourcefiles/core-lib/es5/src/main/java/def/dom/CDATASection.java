package def.dom;
public class CDATASection extends Text {
    public static CDATASection prototype;
    public CDATASection(){}
}

