package def.dom;
public class HTMLMenuElement extends HTMLElement {
    public Boolean compact;
    public String type;
    public static HTMLMenuElement prototype;
    public HTMLMenuElement(){}
}

