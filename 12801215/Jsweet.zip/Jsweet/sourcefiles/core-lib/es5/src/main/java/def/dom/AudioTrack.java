package def.dom;
public class AudioTrack extends def.js.Object {
    public Boolean enabled;
    public String id;
    public String kind;
    public String label;
    public String language;
    public SourceBuffer sourceBuffer;
    public static AudioTrack prototype;
    public AudioTrack(){}
}

