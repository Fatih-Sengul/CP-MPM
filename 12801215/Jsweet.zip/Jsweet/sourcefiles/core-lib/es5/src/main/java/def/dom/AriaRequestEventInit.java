package def.dom;
@jsweet.lang.Interface
public abstract class AriaRequestEventInit extends EventInit {
    @jsweet.lang.Optional
    public String attributeName;
    @jsweet.lang.Optional
    public String attributeValue;
}

