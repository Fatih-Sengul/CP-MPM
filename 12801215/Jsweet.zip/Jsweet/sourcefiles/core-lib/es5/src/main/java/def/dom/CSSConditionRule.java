package def.dom;
public class CSSConditionRule extends CSSGroupingRule {
    public String conditionText;
    public static CSSConditionRule prototype;
    public CSSConditionRule(){}
}

