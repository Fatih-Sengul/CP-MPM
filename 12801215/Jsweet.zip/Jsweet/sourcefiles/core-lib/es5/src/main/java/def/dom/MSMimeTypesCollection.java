package def.dom;
public class MSMimeTypesCollection extends def.js.Object {
    public double length;
    public static MSMimeTypesCollection prototype;
    public MSMimeTypesCollection(){}
}

