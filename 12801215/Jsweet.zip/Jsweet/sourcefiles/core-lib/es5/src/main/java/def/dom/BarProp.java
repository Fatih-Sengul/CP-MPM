package def.dom;
public class BarProp extends def.js.Object {
    public Boolean visible;
    public static BarProp prototype;
    public BarProp(){}
}

