package def.dom;
public class CSSSupportsRule extends CSSConditionRule {
    public static CSSSupportsRule prototype;
    public CSSSupportsRule(){}
}

