package def.dom;
public class MessageChannel extends def.js.Object {
    public MessagePort port1;
    public MessagePort port2;
    public static MessageChannel prototype;
    public MessageChannel(){}
}

