package def.dom;
public class Attr extends Node {
    public String name;
    public Element ownerElement;
    public Boolean specified;
    public String value;
    public static Attr prototype;
    public Attr(){}
}

