package def.dom;
@jsweet.lang.Interface
public abstract class CSS extends def.js.Object {
    native public static Boolean supports(String property, String value);
    native public static Boolean supports(String property);
}

