package def.dom;
public class CSSKeyframeRule extends CSSRule {
    public String keyText;
    public CSSStyleDeclaration style;
    public static CSSKeyframeRule prototype;
    public CSSKeyframeRule(){}
}

