package def.dom;
public class ChannelMergerNode extends AudioNode {
    public static ChannelMergerNode prototype;
    public ChannelMergerNode(){}
}

