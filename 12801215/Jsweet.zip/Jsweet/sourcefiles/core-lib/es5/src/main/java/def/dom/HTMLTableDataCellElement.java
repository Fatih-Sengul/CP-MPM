package def.dom;
public class HTMLTableDataCellElement extends HTMLTableCellElement {
    public static HTMLTableDataCellElement prototype;
    public HTMLTableDataCellElement(){}
}

