package def.dom;
public class ClientRect extends def.js.Object {
    public double bottom;
    public double height;
    public double left;
    public double right;
    public double top;
    public double width;
    public static ClientRect prototype;
    public ClientRect(){}
}

