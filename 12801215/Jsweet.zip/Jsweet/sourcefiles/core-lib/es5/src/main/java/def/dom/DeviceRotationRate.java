package def.dom;
public class DeviceRotationRate extends def.js.Object {
    public double alpha;
    public double beta;
    public double gamma;
    public static DeviceRotationRate prototype;
    public DeviceRotationRate(){}
}

