package def.dom;
public class IDBCursorWithValue extends IDBCursor {
    public Object value;
    public static IDBCursorWithValue prototype;
    public IDBCursorWithValue(){}
}

