package def.dom;
public class CSSPageRule extends CSSRule {
    public String pseudoClass;
    public String selector;
    public String selectorText;
    public CSSStyleDeclaration style;
    public static CSSPageRule prototype;
    public CSSPageRule(){}
}

