package def.dom;
public class Gamepad extends def.js.Object {
    public double[] axes;
    public GamepadButton[] buttons;
    public Boolean connected;
    public String id;
    public double index;
    public String mapping;
    public double timestamp;
    public static Gamepad prototype;
    public Gamepad(){}
}

