package def.dom;
public interface MSLaunchUriCallback {
    public void $apply();
}

