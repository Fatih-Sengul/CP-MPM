package def.dom;
@jsweet.lang.Interface
public abstract class DOML2DeprecatedSizeProperty extends def.js.Object {
    public double size;
}

