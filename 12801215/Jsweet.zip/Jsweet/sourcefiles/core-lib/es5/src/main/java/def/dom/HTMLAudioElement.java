package def.dom;
public class HTMLAudioElement extends HTMLMediaElement {
    public static HTMLAudioElement prototype;
    public HTMLAudioElement(){}
}

