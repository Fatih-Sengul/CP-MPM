package def.dom;
@jsweet.lang.Interface
public abstract class EventInit extends def.js.Object {
    @jsweet.lang.Optional
    public Boolean bubbles;
    @jsweet.lang.Optional
    public Boolean cancelable;
}

