package def.dom;
@jsweet.lang.Interface
public abstract class EventListenerObject extends def.js.Object {
    native public void handleEvent(Event evt);
}

