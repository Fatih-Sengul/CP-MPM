package def.dom;
public class ChannelSplitterNode extends AudioNode {
    public static ChannelSplitterNode prototype;
    public ChannelSplitterNode(){}
}

