package def.dom;
@jsweet.lang.Interface
public abstract class BlobPropertyBag extends def.js.Object {
    @jsweet.lang.Optional
    public String type;
    @jsweet.lang.Optional
    public String endings;
}

