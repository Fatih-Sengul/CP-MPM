package def.dom;
import def.js.Uint8Array;
public class MSMediaKeyMessageEvent extends Event {
    public String destinationURL;
    public Uint8Array message;
    public static MSMediaKeyMessageEvent prototype;
    public MSMediaKeyMessageEvent(){}
}

