/** (translated by www.jsweet.org) */
@jsweet.lang.Name("Intl")
package def.dom.intl;
