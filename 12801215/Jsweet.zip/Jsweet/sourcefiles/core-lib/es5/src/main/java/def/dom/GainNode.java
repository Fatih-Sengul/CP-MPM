package def.dom;
public class GainNode extends AudioNode {
    public AudioParam gain;
    public static GainNode prototype;
    public GainNode(){}
}

