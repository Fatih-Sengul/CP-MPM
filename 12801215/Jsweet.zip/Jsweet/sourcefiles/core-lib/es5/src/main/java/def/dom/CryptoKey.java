package def.dom;
public class CryptoKey extends def.js.Object {
    public KeyAlgorithm algorithm;
    public Boolean extractable;
    public String type;
    public String[] usages;
    public static CryptoKey prototype;
    public CryptoKey(){}
}

