package def.dom;
public class Comment extends CharacterData {
    public String text;
    public static Comment prototype;
    public Comment(){}
}

