package def.dom;
public class HTMLLIElement extends HTMLElement {
    public String type;
    /**
      * Sets or retrieves the value of a list item.
      */
    public double value;
    public static HTMLLIElement prototype;
    public HTMLLIElement(){}
}

