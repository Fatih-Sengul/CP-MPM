package def.dom;
public interface MSExecAtPriorityFunctionCallback {
    public Object $apply(Object... args);
}

