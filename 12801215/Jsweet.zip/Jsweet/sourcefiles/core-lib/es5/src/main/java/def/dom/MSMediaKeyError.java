package def.dom;
public class MSMediaKeyError extends def.js.Object {
    public double code;
    public double systemCode;
    public double MS_MEDIA_KEYERR_CLIENT;
    public double MS_MEDIA_KEYERR_DOMAIN;
    public double MS_MEDIA_KEYERR_HARDWARECHANGE;
    public double MS_MEDIA_KEYERR_OUTPUT;
    public double MS_MEDIA_KEYERR_SERVICE;
    public double MS_MEDIA_KEYERR_UNKNOWN;
    public static MSMediaKeyError prototype;
    public MSMediaKeyError(){}
}

