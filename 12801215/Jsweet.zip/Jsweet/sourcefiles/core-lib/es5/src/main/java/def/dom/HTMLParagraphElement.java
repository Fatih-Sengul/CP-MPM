package def.dom;
public class HTMLParagraphElement extends HTMLElement {
    /**
      * Sets or retrieves how the object is aligned with adjacent text. 
      */
    public String align;
    public String clear;
    public static HTMLParagraphElement prototype;
    public HTMLParagraphElement(){}
}

