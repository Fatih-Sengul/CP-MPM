package def.dom;
public class HTMLHtmlElement extends HTMLElement {
    /**
      * Sets or retrieves the DTD version that governs the current document.
      */
    public String version;
    public static HTMLHtmlElement prototype;
    public HTMLHtmlElement(){}
}

