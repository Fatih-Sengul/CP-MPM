package def.dom;
public class HTMLTrackElement extends HTMLElement {
    @jsweet.lang.Name("default")
    public Boolean Default;
    public String kind;
    public String label;
    public double readyState;
    public String src;
    public String srclang;
    public TextTrack track;
    public double ERROR;
    public double LOADED;
    public double LOADING;
    public double NONE;
    public static HTMLTrackElement prototype;
    public HTMLTrackElement(){}
}

