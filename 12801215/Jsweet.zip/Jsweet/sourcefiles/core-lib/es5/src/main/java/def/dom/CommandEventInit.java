package def.dom;
@jsweet.lang.Interface
public abstract class CommandEventInit extends EventInit {
    @jsweet.lang.Optional
    public String commandName;
    @jsweet.lang.Optional
    public String detail;
}

