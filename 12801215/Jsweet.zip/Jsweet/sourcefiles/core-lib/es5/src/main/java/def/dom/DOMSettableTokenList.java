package def.dom;
public class DOMSettableTokenList extends DOMTokenList {
    public String value;
    public static DOMSettableTokenList prototype;
    public DOMSettableTokenList(){}
}

