package def.dom;
public class CSSNamespaceRule extends CSSRule {
    public String namespaceURI;
    public String prefix;
    public static CSSNamespaceRule prototype;
    public CSSNamespaceRule(){}
}

