package def.dom;
public class AudioDestinationNode extends AudioNode {
    public double maxChannelCount;
    public static AudioDestinationNode prototype;
    public AudioDestinationNode(){}
}

