package def.dom;
import def.js.Uint8Array;
public class MSMediaKeyNeededEvent extends Event {
    public Uint8Array initData;
    public static MSMediaKeyNeededEvent prototype;
    public MSMediaKeyNeededEvent(){}
}

