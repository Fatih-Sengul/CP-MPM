package def.dom;
public interface FunctionStringCallback {
    public void $apply(String data);
}

