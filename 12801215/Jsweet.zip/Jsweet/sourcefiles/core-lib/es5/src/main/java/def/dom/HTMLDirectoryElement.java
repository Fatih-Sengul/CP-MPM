package def.dom;
public class HTMLDirectoryElement extends HTMLElement {
    public Boolean compact;
    public static HTMLDirectoryElement prototype;
    public HTMLDirectoryElement(){}
}

