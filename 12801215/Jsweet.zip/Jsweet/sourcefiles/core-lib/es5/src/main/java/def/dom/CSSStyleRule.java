package def.dom;
public class CSSStyleRule extends CSSRule {
    public Boolean readOnly;
    public String selectorText;
    public CSSStyleDeclaration style;
    public static CSSStyleRule prototype;
    public CSSStyleRule(){}
}

