package def.dom;
/** This is an automatically generated object type (see the source definition). */
@jsweet.lang.ObjectType
public class Audio extends def.js.Object {
    public Audio(String src){}
    public Audio(){}
}

