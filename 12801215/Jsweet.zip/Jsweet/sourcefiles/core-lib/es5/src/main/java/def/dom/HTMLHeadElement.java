package def.dom;
public class HTMLHeadElement extends HTMLElement {
    public String profile;
    public static HTMLHeadElement prototype;
    public HTMLHeadElement(){}
}

