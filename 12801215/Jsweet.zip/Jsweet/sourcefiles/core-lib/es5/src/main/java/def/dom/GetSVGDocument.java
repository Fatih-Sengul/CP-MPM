package def.dom;
@jsweet.lang.Interface
public abstract class GetSVGDocument extends def.js.Object {
    native public Document getSVGDocument();
}

