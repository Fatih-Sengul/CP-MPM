package def.dom;
public class CryptoKeyPair extends def.js.Object {
    public CryptoKey privateKey;
    public CryptoKey publicKey;
    public static CryptoKeyPair prototype;
    public CryptoKeyPair(){}
}

