package def.dom;
public class HTMLTableHeaderCellElement extends HTMLTableCellElement {
    /**
      * Sets or retrieves the group of cells in a table to which the object's information applies.
      */
    public String scope;
    public static HTMLTableHeaderCellElement prototype;
    public HTMLTableHeaderCellElement(){}
}

