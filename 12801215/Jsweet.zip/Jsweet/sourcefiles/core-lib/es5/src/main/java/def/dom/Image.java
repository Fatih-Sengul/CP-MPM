package def.dom;
/** This is an automatically generated object type (see the source definition). */
@jsweet.lang.ObjectType
public class Image extends def.js.Object {
    public Image(double width, double height){}
    public Image(double width){}
    public Image(){}
}

