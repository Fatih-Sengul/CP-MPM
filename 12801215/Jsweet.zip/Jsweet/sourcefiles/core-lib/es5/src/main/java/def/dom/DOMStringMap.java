package def.dom;
public class DOMStringMap extends def.js.Object {
    native public java.lang.String $get(String name);
    public static DOMStringMap prototype;
    public DOMStringMap(){}
}

