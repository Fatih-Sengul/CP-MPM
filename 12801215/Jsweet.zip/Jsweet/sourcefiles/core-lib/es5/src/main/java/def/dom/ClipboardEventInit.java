package def.dom;
@jsweet.lang.Interface
public abstract class ClipboardEventInit extends EventInit {
    @jsweet.lang.Optional
    public String data;
    @jsweet.lang.Optional
    public String dataType;
}

