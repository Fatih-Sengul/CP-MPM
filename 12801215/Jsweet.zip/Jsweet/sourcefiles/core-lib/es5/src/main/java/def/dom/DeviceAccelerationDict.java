package def.dom;
@jsweet.lang.Interface
public abstract class DeviceAccelerationDict extends def.js.Object {
    @jsweet.lang.Optional
    public double x;
    @jsweet.lang.Optional
    public double y;
    @jsweet.lang.Optional
    public double z;
}

