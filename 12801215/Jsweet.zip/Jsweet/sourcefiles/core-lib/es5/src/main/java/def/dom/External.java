package def.dom;
public class External extends def.js.Object {
    public static External prototype;
    public External(){}
}

