package def.dom;
@jsweet.lang.Interface
public abstract class IDBObjectStoreParameters extends def.js.Object {
    @jsweet.lang.Optional
    public jsweet.util.union.Union<String,String[]> keyPath;
    @jsweet.lang.Optional
    public Boolean autoIncrement;
}

