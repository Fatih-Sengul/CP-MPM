package def.dom;
public class CanvasGradient extends def.js.Object {
    native public void addColorStop(double offset, String color);
    public static CanvasGradient prototype;
    public CanvasGradient(){}
}

