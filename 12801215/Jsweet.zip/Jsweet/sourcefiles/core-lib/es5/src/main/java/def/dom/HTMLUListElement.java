package def.dom;
public class HTMLUListElement extends HTMLElement {
    public Boolean compact;
    public String type;
    public static HTMLUListElement prototype;
    public HTMLUListElement(){}
}

