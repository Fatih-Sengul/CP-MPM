package def.dom;
public class DeviceAcceleration extends def.js.Object {
    public double x;
    public double y;
    public double z;
    public static DeviceAcceleration prototype;
    public DeviceAcceleration(){}
}

