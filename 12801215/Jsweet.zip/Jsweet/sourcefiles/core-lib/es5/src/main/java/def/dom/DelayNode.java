package def.dom;
public class DelayNode extends AudioNode {
    public AudioParam delayTime;
    public static DelayNode prototype;
    public DelayNode(){}
}

