package def.dom;
@jsweet.lang.Interface
public abstract class DeviceRotationRateDict extends def.js.Object {
    @jsweet.lang.Optional
    public double alpha;
    @jsweet.lang.Optional
    public double beta;
    @jsweet.lang.Optional
    public double gamma;
}

