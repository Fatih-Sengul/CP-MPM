package def.dom;
public class HTMLPictureElement extends HTMLElement {
    public static HTMLPictureElement prototype;
    public HTMLPictureElement(){}
}

