
enum StatusEnum {
    connected, connecting,
    failed, waiting, offline
}

enum Enum {
    a = 0,
    b = 1,
    c= -1
}

enum StatusEnum2 {
    connected, connecting,
    failed, waiting, offline,
}

enum Enum {
    a = +1,
    b = 0xFF
}

export const enum FormType
{
    Undefined = 0,
    Create = 1,
    Update = 2,
    ReadOnly = 3,
    Disabled = 4,
    BulkEdit = 6
}

