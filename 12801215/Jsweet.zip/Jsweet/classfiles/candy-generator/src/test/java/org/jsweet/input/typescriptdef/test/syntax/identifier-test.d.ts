

interface I {

    "[": number; // = 219,
    "\\": number; // = 220,
    "]": number; // = 221,
    
    
    '[': number; // = 219,
    '\\': number; // = 220,
    ']': number; // = 221,
    
}