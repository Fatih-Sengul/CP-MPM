

/**
 * $I1$
 */
interface I1 {
}

/**
 * $f1$
 */
declare function f1(): string;

/**
 * $I2$
 */
interface I2 {
}

/**
 * $m$
 */

module m {

    /**
     * $I3$
     */
    
    interface I3 {
        
        /**
         * $f2$
         */
        f2();
        
        /**
         * $v1$
         */
        v1: number;        
        
    }
    
}
