
export namespace m1 {

    export namespace m11 {

        export function f111(): void;

    }
    
    export namespace Utils {

        export function f(): void;

    }

    export namespace Utils2 {

        export function f(): C;

        class C {
        }
        
    }
    
}