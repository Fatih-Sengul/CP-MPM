JSweet Language Specifications
==============================

Version: 2.x (snapshot)

Author          : Renaud Pawlak

Author assistant: Louis Grignon

JSweet JavaDoc API: http://www.jsweet.org/core-api-javadoc/

Note: this markdown is automatically generated from the Latex source file. Do not modify directly.

Content
-------
