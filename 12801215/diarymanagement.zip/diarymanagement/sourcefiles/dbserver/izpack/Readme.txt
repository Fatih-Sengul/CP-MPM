Thank you for choosing the TBA Diary Management System.

If this is you first time using this software, please ensure
that you select the Manual to be installed and read through it

You can visit the project at its Source Forge page at
https://sourceforge.net/projects/diarymanagement/