
-- Drop Trigger
DROP TRIGGER fki_passwordSalts_USER_users_USER;


-- Drop Trigger
DROP TRIGGER fku_passwordSalts_USER_users_USER;


-- Drop Trigger
DROP TRIGGER fkd_passwordSalts_USER_users_USER;

-- Drop Trigger
DROP TRIGGER fki_userSessions_USER_users_USER;

-- Drop Trigger
DROP TRIGGER fku_userSessions_USER_users_USER;

-- Drop Trigger
DROP TRIGGER fkd_userSessions_USER_users_USER;

-- Drop Trigger
DROP TRIGGER fki_diary_OWNER_users_USER;

-- Drop Trigger
DROP TRIGGER fku_diary_OWNER_users_USER;

-- Drop Trigger
DROP TRIGGER fkd_diary_OWNER_users_USER;

-- Drop Trigger
DROP TRIGGER fki_diaries_USER_users_USER;

-- Drop Trigger
DROP TRIGGER fku_diaries_USER_users_USER;

-- Drop Trigger
DROP TRIGGER fkd_diaries_USER_users_USER;

-- Drop Trigger
DROP TRIGGER fki_diaries_DIARYID_diary_ID;

-- Drop Trigger
DROP TRIGGER fku_diaries_DIARYID_diary_ID;

-- Drop Trigger
DROP TRIGGER fkd_diaries_DIARYID_diary_ID;

-- Drop Trigger
DROP TRIGGER fki_entries_DIARYID_diary_ID;

-- Drop Trigger
DROP TRIGGER fku_entries_DIARYID_diary_ID;

-- Drop Trigger
DROP TRIGGER fkd_entries_DIARYID_diary_ID;

-- Drop Trigger
DROP TRIGGER fki_entries_USER_users_USER;

-- Drop Trigger
DROP TRIGGER fku_entries_USER_users_USER;

-- Drop Trigger
DROP TRIGGER fkd_entries_USER_users_USER;

